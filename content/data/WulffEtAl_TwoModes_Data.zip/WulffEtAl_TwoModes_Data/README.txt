Data of Wulff, D. U., Mergenthaler-Canseco, M., & Hertwig, R. (2018). A meta-analytic review of two modes of learning and the description-experience gap. Psychological bulletin, 144(2), 140-176.

If you have any questions, send me an email at dirk.wulff@gmail.com

Have fun with the data!

Dirk